const express = require ('express');
const path = require('path'); //path is an inbuilt module
const port = 8000;
const bodyparser = require('body-parser'); //body parser
const app = express(); //All the functionalities of express are present within it
//Telling Express that ejs is the template engine we are going to use here
app.set('view engine', 'ejs')
//looks for folder views in porject folder
app.set('views', path.join(__dirname,'views'));// __dirname makes the process dynamic as using dirname we don't have to change the file path again2 
app.use(bodyparser.urlencoded({extended:false})); //body parser
//middleware1 for experiment purpose
app.use(function(req,res,next){
   console.log('middleware1 called');
   next(); //takes to the next statement 
});
//middleware2 for experiment purpose
app.use(function(req,res,next){
    console.log('Middleware 2 called');
    next();
});
app.use(express.static('assets'));

//Making a global variable 
var contactList = [
    {
        name:"Siddharth",
        PhoneNo:"6845939857"
    },
    {
        name: "Samantha",
        PhoneNo: "9854094258"
    },
    {
        name: "Shawn",
        PhoneNo: "4256487998"
    }
]



//returning a reponse and / below represnt the route: this is where the route will be placed
//You can handle any kind of request here only this makes express superhandy and realiable
//app.get => this is a controller
//context
app.get('/', function(req, res){
    return res.render('home', {
        title: "Contact List",
        //since we need to pass the data to the contact list we'll make it a part of context 
        //We'll add a key called contact-list
        contact_list: contactList
    }); //creating the object and placing the value of title, pages will not update the value they'll the reload the page everytime the value is changed
});

app.get('/practice',function(req,res){
    return res.render('practice', {
        title: "Let us play with ejs"
    });
});
//Another controller for adding contacts to the database
//to add number to the database
app.post('/create-contact', function(req,res){
    // return res.redirect('/practice')
    contactList.push(req.body); 

    return res.redirect('back');
});

app.get('/delete-contact/:PhoneNo', function(req,res){
    console.log(req.params);
    let phone = req.params.phone;
})
//deleting contact
app.get('/delete-contact/', function(req, res){
    console.log(req.query);
    let phone = req.query.phone

    let contactindex = contactList.findIndex(contact => contact.phone == phone);

    if(contactindex != -1){
        contactList.splice(contactindex, 1);
    }

    return res.redirect('back');
});



// running the server listening to request 
app.listen(port, function(err){
    if (err){
        console.log('Error in running the server', err);
    }

    console.log('Yup! Express server is running on port: ', port);
});